//用户id
export const id = state => state.id;

 
