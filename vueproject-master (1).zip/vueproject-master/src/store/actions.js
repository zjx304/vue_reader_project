// import http from 'http/index.js'

// 消息模块全都取消按钮
export const cancelRead = (context, id, index) => {
    // context.commit('cancelRead', id, index);
    // context.commit('buriedPoint', '210005');
}
