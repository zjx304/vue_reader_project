<template>
  <section class="list">
    <div>查看更多列表页</div>
  </section>
</template>

<script>
export default {
  name:'list'
}
</script>

<style>

</style>
